import { Component, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { provideNativeDateAdapter } from '@angular/material/core';
import { ChartDataset, ChartOptions } from 'chart.js';

@Component({
  selector: 'app-date-filter',
  templateUrl: './date-filter.component.html',
  styleUrl: './date-filter.component.css',
  providers: [provideNativeDateAdapter()],
})
export class DateFilterComponent {
  public lineChartLabels = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
  public lineChartOptions: ChartOptions = {responsive: true};
  public LineChartData: ChartDataset[] = [
    { data: [65, 59, 80, 81, 56, 55, 40,78,28,19,90,53], label: 'Dataset 1' },
   { data: [28, 48, 40, 19, 86, 27, 90,60,58,78,9,44,13], label: 'Dataset 2' },
   { data: [18, 48, 77, 9, 100, 27, 40,38,8,69,70,23], label: 'Dataset 3' }
  ];
   public data = this.LineChartData

   filteredData: ChartDataset[] = [];
   rangeFormGroup: FormGroup = new FormGroup({
    start: new FormControl(),
    end: new FormControl()
  });
  startDate:Date|null=null;
  endDate:Date|null=null;


  constructor(){
    this.filterData();
  }
  filterData() {
    this.startDate = this.rangeFormGroup.get('start')?.value;
    this.endDate = this.rangeFormGroup.get('end')?.value;

    if (this.startDate && this.endDate) {
      const startMonth = this.startDate.getMonth();
      const endMonth = this.endDate.getMonth();
      this.data = this.LineChartData.map(dataset => {
        return {
          data: dataset.data.slice(startMonth, endMonth + 1),
          label: dataset.label
        };
      });
    } else {
      this.data = this.LineChartData;
    }
  }
  resetDataset(){
    this.data = this.LineChartData;
  }



}
